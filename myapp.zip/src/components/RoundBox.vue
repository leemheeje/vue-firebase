<template>
    <div class="cmmCard">
        <slot></slot>
    </div>
</template>
<script>
export default {
    props: []
};
</script>