<template>
  <div class="header">
    <Navi></Navi>
  </div>
</template>

<script>
import Navi from '@/components/Navi'
export default {
  name: "home",
  components: {
    Navi
  }
};
</script>
