<template>
<div class="container">
    <div class="errorWrap">
        404
    </div>
</div>
</template>