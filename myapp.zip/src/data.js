export default{
	data() {
		return {
			allDataFortfolio : [
                {
						main_thumb: 'https://cdn.dribbble.com/users/1192538/screenshots/8132399/media/18b4793f16eb01d0b731bc8dd8562e6d.png',
                        name : '수차우수아아아아아아아',
                        title : '수차우수아아아아아아아수차우수아아아아아아아수차우수아아아아아아아',
                        stitle : 'Food app design exploration...Images by Duc Bui from Behance\nHope you like this.\nFeel free to share your views on this.',
                        email : 'email',
						user_thumb: 'https://cdn.dribbble.com/users/2380754/avatars/small/6042030ece03081fcfb117c088e1b49d.png?1565962800',
						favorite : 1,
                        comment_length: 87,
                        count_view : 184,
                        uid:'qhWFlrmXBESEBYNWuI3qwLwXTmv2'
                },
                {
						main_thumb: 'https://cdn.dribbble.com/users/2293589/screenshots/8126069/media/d67d6d89bcc566ab2706b9e5e33aef8b.png',
                        name : 'asdt',
                        title : 'tttts',
                        stitle : 'Food app design exploration...Images by Duc Bui from Behance\nHope you like this.\nFeel free to share your views on this.',
                        email : 'email',
						user_thumb: 'https://cdn.dribbble.com/users/2293589/avatars/small/84fcfee0b593dc473e85a6c4193b1eff.png?1553955029',
						favorite : 1,
                        comment_length: 87,
                        count_view : 265,
                        uid:'qhWFlrmXBESEBYNWuI3qwLwXTmv2'
                },
                {
						main_thumb: 'https://cdn.dribbble.com/users/2058952/screenshots/8175396/media/8f218bd100e82c4bf34cd27008465879.png',
                        name : 'asdt',
                        title : 'tttts',
                        stitle : 'Food app design exploration...Images by Duc Bui from Behance\nHope you like this.\nFeel free to share your views on this.',
                        email : 'email',
						user_thumb: 'https://cdn.dribbble.com/users/2058952/avatars/small/f537d5e43d2de11547eaa664e0834af0.png?1563419742',
						favorite : 1,
                        comment_length: 87,
                        count_view : 346,
                        uid:'qhWFlrmXBESEBYNWuI3qwLwXTmv2'
                },
                {
						main_thumb: 'https://cdn.dribbble.com/users/14268/screenshots/8173543/media/57bec88a273168331f56b94b2fbf78fc.png',
                        name : 'asdt',
                        title : 'tttts',
                        stitle : 'Food app design exploration...Images by Duc Bui from Behance\nHope you like this.\nFeel free to share your views on this.',
                        email : 'email',
						user_thumb: 'https://cdn.dribbble.com/users/14268/avatars/small/764193ea1bc7f0edf846eeda47048538.jpg?1549567039',
						favorite : 1,
                        comment_length: 87,
                        count_view : 427,
                        uid:'qhWFlrmXBESEBYNWuI3qwLwXTmv2'
                },
                {
						main_thumb: 'https://cdn.dribbble.com/users/517584/screenshots/8170514/media/45c6d386a4c3934646fa844ddf0a53d5.png',
                        name : 'asdt',
                        title : 'tttts',
                        stitle : 'Food app design exploration...Images by Duc Bui from Behance\nHope you like this.\nFeel free to share your views on this.',
                        email : 'email',
						user_thumb: 'https://cdn.dribbble.com/users/517584/avatars/small/d86079a69573bdf9f5ad7bfcbc6c2da6.jpg?1567411872',
						favorite : 1,
                        comment_length: 87,
                        count_view : 508,
                        uid:'qhWFlrmXBESEBYNWuI3qwLwXTmv2'
                },
                {
						main_thumb: 'https://cdn.dribbble.com/users/175710/screenshots/8172881/media/8b276ce75a51f93d021e3e65e57cfaef.png',
                        name : 'asdt',
                        title : 'tttts',
                        stitle : 'Food app design exploration...Images by Duc Bui from Behance\nHope you like this.\nFeel free to share your views on this.',
                        email : 'email',
						user_thumb: 'https://cdn.dribbble.com/users/175710/avatars/small/47086dcf36c1c5801ee2f1ef31f17f4b.png?1564443649',
						favorite : 1,
                        comment_length: 87,
                        count_view : 589,
                        uid:'qhWFlrmXBESEBYNWuI3qwLwXTmv2'
                },
                {
						main_thumb: 'https://cdn.dribbble.com/users/1061675/screenshots/8109869/media/dec7397f93fdf82d51db90666ac62580.png',
                        name : 'asdt',
                        title : 'tttts',
                        stitle : 'Food app design exploration...Images by Duc Bui from Behance\nHope you like this.\nFeel free to share your views on this.',
                        email : 'email',
						user_thumb: 'https://cdn.dribbble.com/users/1061675/avatars/small/a8d793839b7afb9ce5f48d4c90e32667.png?1554664254',
						favorite : 1,
                        comment_length: 87,
                        count_view : 670,
                        uid:'qhWFlrmXBESEBYNWuI3qwLwXTmv2'
                }, {
                    main_thumb: 'https://cdn.dribbble.com/users/517584/screenshots/8170514/media/45c6d386a4c3934646fa844ddf0a53d5.png',
                    name : 'asdt',
                    title : 'tttts',
                    stitle : 'Food app design exploration...Images by Duc Bui from Behance\nHope you like this.\nFeel free to share your views on this.',
                    email : 'email',
                    user_thumb: 'https://cdn.dribbble.com/users/517584/avatars/small/d86079a69573bdf9f5ad7bfcbc6c2da6.jpg?1567411872',
                    favorite : 1,
                    comment_length: 87,
                    count_view : 751,
                    uid:'qhWFlrmXBESEBYNWuI3qwLwXTmv2'
            }, {
                    main_thumb: 'https://cdn.dribbble.com/users/2293589/screenshots/8126069/media/d67d6d89bcc566ab2706b9e5e33aef8b.png',
                    name : 'asdt',
                    title : 'tttts',
                    stitle : 'Food app design exploration...Images by Duc Bui from Behance\nHope you like this.\nFeel free to share your views on this.',
                    email : 'email',
                    user_thumb: 'https://cdn.dribbble.com/users/2293589/avatars/small/84fcfee0b593dc473e85a6c4193b1eff.png?1553955029',
                    favorite : 1,
                    comment_length: 87,
                    count_view : 832,
                    uid:'qhWFlrmXBESEBYNWuI3qwLwXTmv2'
                }
            ]
		}
	}
}