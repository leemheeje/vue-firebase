export default {
	apiKey: "AIzaSyDB7HzvXTSPXLEcILXX62nBr-amgYBIqFQ",
	authDomain: "vue-firebase-9f173.firebaseapp.com",
	databaseURL: "https://vue-firebase-9f173.firebaseio.com",
	projectId: "vue-firebase-9f173",
	storageBucket: "vue-firebase-9f173.appspot.com",
	messagingSenderId: "345961742340",
	appId: "1:345961742340:web:003240b44bb841435bb551",
	measurementId: "G-7VFMWNT80Q"
};